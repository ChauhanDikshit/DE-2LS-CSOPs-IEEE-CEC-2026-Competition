% 批量将 .mat 转为 .txt
folder = 'D:\各文档\班旋旋\师爷技术报告\CEC2026\结果\最终结果\UDE_IV\';
files = dir(fullfile(folder, '*.mat'));

for i = 1:length(files)
    filename = fullfile(folder, files(i).name);
    [~, name, ~] = fileparts(files(i).name);
    
    try
        % 方案1: 先试二进制读取
        data = load(filename);
        vars = fieldnames(data);
        d = data.(vars{1});
    catch
        try
            % 方案2: 二进制失败，尝试 ASCII 文本读取
            d = load(filename, '-ascii');
        catch
            % 方案3: 可能是 HDF5 (v7.3) 格式
            try
                info = h5info(filename);
                d = h5read(filename, '/' + info.Datasets(1).Name);
            catch
                fprintf('无法读取: %s\n', files(i).name);
                continue;
            end
        end
    end
    
    % 保存为 txt
    outname = fullfile(folder, [name, '.txt']);
    writematrix(d, outname);
    fprintf('已转换: %s -> %s\n', files(i).name, [name, '.txt']);
end

disp('转换完成！');
